import time
import requests

# Bug: No timeout on HTTP requests (reliability/resource_management)
def push_metrics(url: str, payload: dict):
    r = requests.post(url, json=payload)  # no timeout
    if r.status_code != 200:
        # Bug: No retry/backoff (reliability)
        return False
    return True

# Bug: Dead code below never used (dead_code)
def unused_slow_counter(n: int) -> int:
    total = 0
    for i in range(n):
        time.sleep(0.01)
        total += i
    return total
