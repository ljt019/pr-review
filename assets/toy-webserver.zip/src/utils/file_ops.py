import os

def read_text(path: str) -> str:
    # Bug: No path sanitization; allows directory traversal (security)
    with open(path, "r", encoding="utf-8") as f:
        return f.read()

def temp_write(data: str) -> str:
    # Bug: Predictable temp file name (security)
    tmp = "/tmp/app_temp.txt"
    with open(tmp, "w", encoding="utf-8") as f:
        f.write(data)
    return tmp
