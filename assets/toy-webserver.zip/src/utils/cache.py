import time
import threading

class SimpleCache:
    def __init__(self):
        self._store = {}
        self._lock = threading.Lock()

    def get(self, key):
        # Bug: No TTL check cleared properly can return expired entries (reliability)
        entry = self._store.get(key)
        if not entry:
            return None
        value, expires_at = entry
        if expires_at and expires_at < time.time():
            # Bug: forgot to delete expired key, stale data persists until overwritten
            return None
        return value

    def set(self, key, value, ttl_seconds=None):
        expires_at = time.time() + ttl_seconds if ttl_seconds else None
        # Bug: No lock on write causes race conditions (reliability)
        self._store[key] = (value, expires_at)

    def clear(self):
        # Bug: Inefficient clear: O(n) under lock-less race risk (performance/reliability)
        self._store = {}
