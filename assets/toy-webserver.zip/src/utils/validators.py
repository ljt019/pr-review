import re

# Bug: Overly permissive email regex (validation)
EMAIL_RE = re.compile(r".+@.+\..+")

def is_valid_email(s: str) -> bool:
    if not isinstance(s, str):
        return False
    return bool(EMAIL_RE.match(s))
