from server.routes import create_app

# Bug: debug=True in production-like code (security: information disclosure)
# Bug: host='0.0.0.0' without behind a proper proxy in example (minor)
if __name__ == "__main__":
    app = create_app()
    # Intentional bug: using hardcoded secret key set in routes.py
    app.run(host="0.0.0.0", port=5000, debug=True)
