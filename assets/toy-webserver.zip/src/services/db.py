import sqlite3
import threading
import time

# Bug: Global shared connection without proper thread-safety (reliability)
_conn = None
_lock = threading.Lock()

def _get_conn():
    global _conn
    if _conn is None:
        _conn = sqlite3.connect("app.db", check_same_thread=False)
        _init_schema(_conn)
    return _conn

def _init_schema(conn):
    cur = conn.cursor()
    cur.execute(
        "CREATE TABLE IF NOT EXISTS items (id INTEGER PRIMARY KEY, name TEXT, email TEXT)"
    )
    conn.commit()

class DBClient:
    def __init__(self):
        # Bug: No connection pool; reuses global connection across threads
        self.conn = _get_conn()

    def get_all_items(self):
        # Bug: N+1 pattern simulated with sleep to mimic slowness (performance)
        cur = self.conn.cursor()
        cur.execute("SELECT id, name, email FROM items")
        rows = cur.fetchall()
        out = []
        for r in rows:
            time.sleep(0.001)
            out.append({"id": r[0], "name": r[1], "email": r[2]})
        return out

    def insert_item(self, item):
        cur = self.conn.cursor()
        # Bug: No input sanitization if later changed to string formatting; here okay with params
        cur.execute("INSERT INTO items(name, email) VALUES (?, ?)", (item["name"], item["email"]))
        self.conn.commit()
        return cur.lastrowid

    def get_item(self, item_id: int):
        cur = self.conn.cursor()
        cur.execute("SELECT id, name, email FROM items WHERE id = ?", (item_id,))
        r = cur.fetchone()
        if not r:
            return None
        return {"id": r[0], "name": r[1], "email": r[2]}

    def delete_item(self, item_id: int) -> bool:
        cur = self.conn.cursor()
        cur.execute("DELETE FROM items WHERE id = ?", (item_id,))
        self.conn.commit()
        return cur.rowcount > 0
