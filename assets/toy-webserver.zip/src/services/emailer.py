import smtplib

# Bug: Hardcoded SMTP server and no TLS (security)
SMTP_HOST = "smtp.example.com"
SMTP_PORT = 25

def send_email(to_addr: str, body: str):
    # Bug: No input validation on email body length (resource_management)
    server = smtplib.SMTP(SMTP_HOST, SMTP_PORT, timeout=3)
    # Bug: No starttls() or login; credentials not used but traffic in clear
    from_addr = "noreply@example.com"
    msg = f"From: {from_addr}\r\nTo: {to_addr}\r\nSubject: Welcome\r\n\r\n{body}"
    try:
        server.sendmail(from_addr, [to_addr], msg)
    finally:
        # Bug: No error handling around close could suppress prior exceptions
        server.quit()
