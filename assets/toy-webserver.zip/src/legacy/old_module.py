# Bug: Deprecated interface left around; dead code path (dead_code)
def old_function(x):
    y = x * 2
    # Bug: Unreachable code
    if False:
        return y + 1
    return y
