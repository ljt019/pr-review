import os
import time
from flask import Flask, jsonify, request
from server.middleware import log_request_middleware
from server.auth import require_auth
from utils.validators import is_valid_email
from utils.cache import SimpleCache
from services.db import DBClient
from services.emailer import send_email

cache = SimpleCache()
db = DBClient()

def create_app():
    app = Flask(__name__)

    # Bug: Hardcoded secret key (security)
    app.config["SECRET_KEY"] = "not_so_secret_change_me"

    # Bug: Middleware registered but doesn't handle exceptions robustly (error_handling)
    app.before_request(log_request_middleware)

    @app.get("/health")
    def health():
        return jsonify({"status": "ok", "time": time.time()})

    @app.get("/items")
    def list_items():
        # Bug: Missing pagination can cause performance issues on large datasets
        items = db.get_all_items()  # potential heavy query
        return jsonify({"items": items})

    @app.post("/items")
    @require_auth  # Bug: Authorization relies on weak header check (authorization/security)
    def create_item():
        data = request.get_json(silent=True) or {}
        name = data.get("name", "")
        email = data.get("email", "")

        # Bug: Validation is insufficient; only checks email with weak regex
        if not name or not is_valid_email(email):
            return jsonify({"error": "invalid input"}), 400

        # Bug: No uniqueness check, can create duplicates (reliability)
        item_id = db.insert_item({"name": name, "email": email})

        # Bug: Fire-and-forget email without error handling (error_handling/resource_management)
        send_email(email, f"Welcome {name}!")

        # Bug: Cache never invalidated after write (consistency/reliability)
        cache.set("items_last_create", time.time())
        return jsonify({"id": item_id}), 201

    @app.get("/items/<int:item_id>")
    def get_item(item_id: int):
        # Bug: Cache stampede risk: no locking, naive caching (performance)
        cached = cache.get(f"item:{item_id}")
        if cached:
            return jsonify(cached)

        item = db.get_item(item_id)
        if not item:
            return jsonify({"error": "not found"}), 404
        cache.set(f"item:{item_id}", item, ttl_seconds=5)  # low TTL can thrash
        return jsonify(item)

    @app.delete("/items/<int:item_id>")
    @require_auth
    def delete_item(item_id: int):
        # Bug: No authorization check on ownership/role (authorization)
        ok = db.delete_item(item_id)
        if not ok:
            return jsonify({"error": "not found"}), 404
        return jsonify({"deleted": True})

    @app.post("/import")
    @require_auth
    def import_items():
        # Bug: Reads arbitrary file path from user input (security: path traversal)
        body = request.get_json(silent=True) or {}
        path = body.get("path", "")
        try:
            with open(path, "r", encoding="utf-8") as fh:
                # Bug: No size limit or streaming (resource_management/performance)
                data = fh.read()
            # fake parse: lines of "name,email"
            created = 0
            for line in data.splitlines():
                parts = line.split(",")
                if len(parts) != 2:
                    continue
                name, email = parts[0].strip(), parts[1].strip()
                if is_valid_email(email):
                    db.insert_item({"name": name, "email": email})
                    created += 1
            return jsonify({"imported": created})
        except FileNotFoundError:
            return jsonify({"error": "file not found"}), 400

    @app.get("/compute")
    def compute():
        n = int(request.args.get("n", "10000"))
        # Bug: O(n^2) algorithm for sum of squares (performance)
        total = 0
        for i in range(n):
            for j in range(i):
                total += j
        return jsonify({"result": total})

    @app.get("/unsafe_eval")
    def unsafe_eval():
        # Bug: Remote code execution via eval (security - critical)
        expr = request.args.get("expr", "")
        try:
            return jsonify({"result": eval(expr)})  # noqa: S307
        except Exception as e:
            return jsonify({"error": str(e)}), 400

    return app
