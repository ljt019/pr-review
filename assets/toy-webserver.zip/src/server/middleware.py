from flask import request

def log_request_middleware():
    # Bug: Logs sensitive headers including Authorization (security/privacy)
    # Intended bug: printing, not using structured logger
    print(
        f"[REQ] {request.method} {request.path} headers={dict(request.headers)}"
    )
