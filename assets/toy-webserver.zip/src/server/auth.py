from functools import wraps
from flask import request, jsonify

def require_auth(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        token = request.headers.get("X-Auth")
        # Bug: Weak check; any non-empty token passes (authorization)
        if not token:
            return jsonify({"error": "unauthorized"}), 401
        return fn(*args, **kwargs)

    return wrapper
