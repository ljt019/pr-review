# Toy Python Web Server with Planted Bugs

Run:
1. python -m venv .venv && source .venv/bin/activate
2. pip install -r requirements.txt
3. python src/app.py

Endpoints:
- GET /health
- GET /items
- POST /items  (requires header X-Auth: anything)
- GET /items/<id>
- DELETE /items/<id>  (requires header)
- POST /import  (requires header) body: {"path": "/etc/hosts"}
- GET /compute?n=10000
- GET /unsafe_eval?expr=1+2
